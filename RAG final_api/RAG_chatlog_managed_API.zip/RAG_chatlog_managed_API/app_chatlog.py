from datetime import datetime
from langchain_google_genai import ChatGoogleGenerativeAI 
from flask import Flask, request, jsonify, render_template, session
from werkzeug.utils import secure_filename
import os
import sys
import time
import random
from langchain_community.document_loaders import PDFPlumberLoader 
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain.storage import InMemoryStore 
from langchain.retrievers import ParentDocumentRetriever
from langchain_experimental.text_splitter import SemanticChunker
from langchain_huggingface.embeddings import HuggingFaceEmbeddings 
from langchain_community.vectorstores import FAISS ,Chroma
from langchain_mistralai.chat_models import ChatMistralAI
from langchain.prompts import PromptTemplate 
from langchain.chains.llm import LLMChain 
from langchain.memory import ConversationBufferMemory
from langchain.chains.combine_documents.stuff import StuffDocumentsChain 
from langchain.chains import RetrievalQA 
from langchain.chains import ConversationalRetrievalChain
from langchain_community.llms import Ollama

from sqlalchemy import create_engine, Column, Text, Integer, String, DateTime, func
from sqlalchemy.orm import sessionmaker, declarative_base

from langchain.globals import set_verbose 
set_verbose(True)



app = Flask(__name__)
app.secret_key = "your_secret_key_here"  # Required for session management

# Configure upload folder with absolute path
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
UPLOAD_FOLDER = os.path.join(BASE_DIR, 'uploads')
ALLOWED_EXTENSIONS = {'pdf'}

app.config['MAX_CONTENT_LENGTH'] = 200 * 1024 * 1024
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure upload directory exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# Global variables to store RAG components
qa_chain = None
current_file = None
memory = None

# Rate limiting configuration
MAX_RETRIES = 5
INITIAL_BACKOFF = 1  # seconds
MAX_BACKOFF = 60  # seconds


##################Data Base connection################################
DATABASE_URL = "mysql+pymysql://root:@localhost/logs"
engine = create_engine(DATABASE_URL, echo=True)
Base = declarative_base()

class ChatLog(Base):
    __tablename__='chat_logs'
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(Integer)
    session_id = Column(Integer)
    human_message = Column(Text)
    ai_message = Column(Text)
    time_stamp = Column(DateTime)

Base.metadata.create_all(engine)

Session=sessionmaker(bind=engine)
db_session=Session()

def add_chatlog(user_id, session_id, human_message, ai_message, time_stamp):
    chat = ChatLog(user_id=user_id, session_id=session_id, human_message=human_message, ai_message=ai_message, time_stamp=time_stamp)
    db_session.add(chat)
    db_session.commit()

max_session_id = db_session.query(func.max(ChatLog.session_id)).scalar()

current_session_id = max_session_id+1 if max_session_id else 50001
print("current session:\n",current_session_id,"\n-----------")
##########################################################################


class RateLimitError(Exception):
    """Custom exception for when we've exhausted retries due to rate limits"""
    pass

def validate_query(query):
    # List of common greetings or short inputs that should bypass RAG
    bypass_terms = ["hi", "hello", "hey", "greetings", "", "hey there", "hi there", "thank you", "thanks"]
    return query.lower().strip() in bypass_terms

def fetch_with_retry(chain, prompt):
    """Execute the chain with exponential backoff retry logic for rate limits"""
    retries = 0
    backoff = INITIAL_BACKOFF
    
    while retries < MAX_RETRIES:
        try:
            return chain({"question": prompt})
        except Exception as e:
            error_str = str(e).lower()
            
            # Check if it's a rate limit error
            if "429" in error_str or "rate limit" in error_str:
                retries += 1
                if retries >= MAX_RETRIES:
                    raise RateLimitError(f"Failed after {MAX_RETRIES} retries due to rate limiting") from e
                
                # Calculate backoff with jitter to prevent thundering herd problem
                jitter = random.uniform(0.8, 1.2)
                sleep_time = min(backoff * jitter, MAX_BACKOFF)
                
                print(f"Rate limit hit. Retrying in {sleep_time:.2f} seconds (attempt {retries}/{MAX_RETRIES})")
                time.sleep(sleep_time)
                
                # Exponential backoff
                backoff = min(backoff * 2, MAX_BACKOFF)
            else:
                # Not a rate limit error, re-raise
                raise

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def chunk_pdf(file_path):
    """Chunk the PDF into smaller parts to handle large files"""
    try:
        loader = PDFPlumberLoader(file_path)
        docs = loader.load()
        
        # Use smaller chunk size for large documents
        # embedder = HuggingFaceEmbeddings()
        # # text_splitter = SemanticChunker(embedder)
        # text_splitter = RecursiveCharacterTextSplitter(separators=['\n\n', '\n'], chunk_size=1000, chunk_overlap=20)
        # documents = text_splitter.split_documents(docs)
        
        return docs
    except Exception as e:
        print(f"Error in chunk_pdf: {str(e)}", file=sys.stderr)
        raise

def initialize_rag(file_path):
    global qa_chain, memory
    
    try:
        print(f"Processing file: {file_path}", file=sys.stderr)
        
        # Chunk the PDF
        documents = chunk_pdf(file_path)
        if not documents:
            raise Exception("No text could be extracted from the PDF")
            
        print(f"Successfully split into {len(documents)} chunks", file=sys.stderr)
        
        # Initialize embeddings and vector store
        embedder = HuggingFaceEmbeddings()
        vector = FAISS.from_documents(documents, embedder)
        # local_db_name = 'batteries'
        # vector.save_local(local_db_name)
        # vector = FAISS.load_local(local_db_name, embedder, allow_dangerous_deserialization=True)
        # retriever = vector.as_retriever(search_type='similarity', search_kwargs={'k': 3})
        parent_splitter = RecursiveCharacterTextSplitter(chunk_size=2500, chunk_overlap=0, separators=['\n\n','\n','.',','])
        child_splitter = RecursiveCharacterTextSplitter(chunk_size=100, chunk_overlap=0, separators=['\n\n','\n','.',','])
        doc_sore = InMemoryStore()

        retriever = ParentDocumentRetriever(
            parent_splitter=parent_splitter, 
            child_splitter=child_splitter, 
            docstore=doc_sore, 
            vectorstore=vector,
            search_kwargs={"search_type":"mmr", "k":4}, 
            verbose=True
        )

        retriever.add_documents(documents)

        # vector = Chroma.from_documents(documents, embedder, persist_directory=r'.\vector_chroma')
        # retriever = vector.as_retriever(search_type='similarity', kwargs={'k':3})
        
        # Initialize LLM with fallback options
        primary_llm = None
        
        try:
            # Try Mistral first
            primary_llm = ChatMistralAI(
                mistral_api_key="pFAmg2W497e135hFcZm0dxqSIzR2txOJ", 
                temperature=0.9, 
                model_name="mistral-small-latest",
                request_timeout=30  # Increase timeout
            )
        except Exception as e:
            print(f"Failed to initialize Mistral: {str(e)}", file=sys.stderr)
            # Fall back to local model
            try:
                primary_llm = Ollama(model="deepseek-r1:1.5b", temperature=0.95)
            except:
                # Final fallback
                print("Falling back to Google Gemini", file=sys.stderr)
                primary_llm = ChatGoogleGenerativeAI(
                    model="gemini-1.5-pro",  
                    temperature=0.99, 
                    api_key="AIzaSyBN1AlkuB9W2EU6rcfJffrKumCzsnrdh4o"
                )
        
        llm = primary_llm
        
        # prompt = """
        # You are a specialized assistant using Retrieval Augmented Generation (RAG).

        # Use the following context and chat history to answer the user's question:

        # 1. If the user greets you, simply respond with "Hi. How can I help you?" without referencing any context.

        # 2. If the user's question cannot be answered based on the provided context, respond only with "Sorry! I don't know." - nothing more.

        # 3. When answering questions based on context, provide clear, concise responses without mentioning the context itself or explaining your process.

        # 4. Focus exclusively on answering the question with relevant information, avoiding unnecessary explanations about limitations, system design, or data sources.

        # Chat History: {chat_history}
        # Context: {context}
        # Question: {question}
        # Helpful Answer:
        # """
        
        prompt="""
        You are a specialized assistant using Retrieval Augmented Generation (RAG).

        Use the following context and chat history to answer the user's question:

        1. If the user greets you, simply respond with "Hi. How can I help you?" without referencing any context.

        2. If the user's question cannot be answered based on the provided context Then try to answer based on the history given. If the question is completely different, then respond only with "Sorry! I don't know." - nothing more.

        3. When answering questions based on context, provide clear, concise responses without mentioning the context itself or explaining your process.

        4. Focus exclusively on answering the question with relevant information, avoiding unnecessary explanations about limitations, system design, or data sources.

        5. Try to provide answer with in 4 lines. 

        6. If the user ask for more detail then you can provide an elaborated answer.
        
        7. Relate the question with the given context to get clear answer. \n

        # Chat History: \n{chat_history}\n
        # Context: \n{context}\n
        # Question: \n{question}\n
        # Helpful Answer:\n        """


        # Initialize memory
        memory = ConversationBufferMemory(
            memory_key="chat_history",
            return_messages=True,
            output_key="answer", 
        )
        
        # Use ConversationalRetrievalChain instead of RetrievalQA
        qa_chain = ConversationalRetrievalChain.from_llm(
            llm=llm,
            retriever=retriever,
            memory=memory,
            return_source_documents=True,
            combine_docs_chain_kwargs={"prompt": PromptTemplate.from_template(prompt)}, 
            verbose=True, 
            rephrase_question = False
        )
        
        return True
    except Exception as e:
        print(f"Error in initialize_rag: {str(e)}", file=sys.stderr)
        raise

@app.route('/')
def index():
    return render_template('index_new.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    global memory
    
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
        
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
        
    if file and allowed_file(file.filename):
        # try:
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            
            # Ensure the uploads directory exists
            os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
            
            # Save the file
            file.save(file_path)
            print(f"File saved to: {file_path}", file=sys.stderr)
            
            # Check if file exists and is readable
            if not os.path.isfile(file_path):
                raise Exception("File was not saved correctly")
            
            # Reset memory when a new file is uploaded
            memory = None
                
            strt_time_ini = datetime.now()
            # Initialize RAG system
            initialize_rag(file_path)
            end_time_ini = datetime.now()
            print(f'Time taken to initialize RAG {(end_time_ini-strt_time_ini).total_seconds()*1000} ms')
            
            # Clear conversation history when a new document is uploaded
            if 'chat_history' in session:
                session.pop('chat_history')
                
            return jsonify({'message': 'File uploaded and processed successfully'}), 200
            
        # except Exception as e:
        #     print(f"Error processing file: {str(e)}", file=sys.stderr)
        #     # Clean up the file if it was saved
        #     if 'file_path' in locals() and os.path.exists(file_path):
        #         try:
        #             os.remove(file_path)
        #         except:
        #             pass
        #     return jsonify({'error': str(e)}), 500
            
    return jsonify({'error': 'Invalid file type'}), 400

@app.route('/chat', methods=['POST'])
def chat():
    if qa_chain is None:
        return jsonify({'error': 'Please upload a PDF file first'}), 400
    
    data = request.json
    if not data or 'question' not in data:
        return jsonify({'error': 'No question provided'}), 400
    
    try:
        # Get the user's question
        question = data['question']
        
        try:
            # if validate_query(question):
                # if 'chat_history' not in session:
                #     session['chat_history'] = []
                    
                #     session['chat_history'].append({
                #         "question": question, 
                #         "answer": "How can i help you?"
                #     })
                #     session.modified = True
                # return jsonify({
                #     'answer': "How can i help you?",
                #     'history': session['chat_history']
                #     }), 200

            # else:
                # Process the question with conversation history and retry logic
                res_st = datetime.now()
                response = fetch_with_retry(qa_chain, question)
                res_end = datetime.now()
                print(f'Time taken for this response: {(res_end-res_st).total_seconds()*1000} ms')
                
                # Store chat for frontend display
                if 'chat_history' not in session:
                    session['chat_history'] = []
                    
                session['chat_history'].append({
                    "question": question, 
                    "answer": response["answer"]
                })
                session.modified = True
                
                add_chatlog(None, current_session_id, question, response['answer'], datetime.now())

                return jsonify({
                    'answer': response["answer"],
                    'history': session['chat_history']
                }), 200
            
        except RateLimitError as e:
            # Handle rate limit exhaustion gracefully
            print(f"Rate limit exhausted: {str(e)}", file=sys.stderr)
            
            # Add a friendly message to chat history
            if 'chat_history' not in session:
                session['chat_history'] = []
                
            error_message = "I'm experiencing high demand right now. Please try again in a few minutes."
            
            session['chat_history'].append({
                "question": question, 
                "answer": error_message
            })
            session.modified = True
            add_chatlog(None, current_session_id, question, f"Error: {error_message}", datetime.now())

            return jsonify({
                'answer': error_message,
                'history': session['chat_history'],
                'rate_limited': True
            }), 429
            
    except Exception as e:
        print(f"Error in chat: {str(e)}", file=sys.stderr)
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True, port=250)