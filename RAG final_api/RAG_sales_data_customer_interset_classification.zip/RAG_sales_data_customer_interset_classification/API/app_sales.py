from datetime import datetime
from langchain_huggingface.embeddings import HuggingFaceEmbeddings
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_experimental.text_splitter import SemanticChunker
from langchain.vectorstores import FAISS 
from langchain_huggingface.embeddings import HuggingFaceEmbeddings 
from langchain.memory import ConversationBufferMemory 
from langchain.chains import ConversationalRetrievalChain
from langchain_mistralai.chat_models import ChatMistralAI 
import pandas as pd
from langchain.prompts import PromptTemplate
import random
import time 
from langchain.chains import LLMChain
from flask import Flask 
from flask import render_template, request, jsonify
from sqlalchemy import create_engine, Column, Text, Integer, DateTime, func
from sqlalchemy.orm import sessionmaker, declarative_base



app = Flask(__name__)


##############connecting db###############################
DATABASE_URL = "mysql+pymysql://root:@localhost/logs"
engine = create_engine(DATABASE_URL, echo=True)
Base = declarative_base()

class ChatLog(Base):
    __tablename__="B2B_Chat_Logs" 
    id = Column(Integer, autoincrement=True, primary_key=True)
    UserId = Column(Integer)
    SessionId = Column(Integer, primary_key=True)
    HumanMessage = Column(Integer)
    AIMessage = Column(Text)
    TimeStamp = Column(DateTime)


class ChatClassify(Base):
    __tablename__="B2B_Chat_Result"
    id = Column(Integer, autoincrement=True, primary_key=True)
    UserId = Column(Integer, primary_key=True)
    SessionId =Column(Integer, primary_key=True)
    WillUserBuy = Column(Text)
    Confidence = Column(Integer) 


# Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
db_session = Session()

def add_chatlogs(userid, sessionid, humanmessage, aimessage, timestamp):
    chat = ChatLog(UserId=userid, SessionId=sessionid, HumanMessage=humanmessage, AIMessage=aimessage, TimeStamp=timestamp)
    db_session.add(chat)
    db_session.commit()

def add_result(userid, sessionid, willuserbuy, confidence):
    chat = ChatClassify(UserId=userid, SessionId=sessionid, WillUserBuy=willuserbuy, Confidence=confidence)
    db_session.add(chat)
    db_session.commit()

def get_current_session_id():
    max_sessionid = db_session.query(func.max(ChatLog.SessionId)).scalar()
    return max_sessionid+1 if max_sessionid else 50000
####################################################################
current_session_id = get_current_session_id()

rag_chain = None
classification_chain = None
memory = None

MAX_RETRIES = 5
INITIAL_BACKOFF = 1  # seconds
MAX_BACKOFF = 60  # seconds

def get_data_ready(path):
    if path.endswith(".xlsx") or path.endswith(".xls"):
        df = pd.read_excel(path, sheet_name="Orders")
        # df = df[:2500]
        text = df.apply(lambda row: " ".join(row.astype(str)), axis=1).to_list()
        
        merged = ''
        for one in text:
            merged = str(merged)+"$"+str(one)
        print(f'One row length {len(text[2])} //// chunk size 100')
        splitter = RecursiveCharacterTextSplitter(separators=['$'], chunk_size=20, chunk_overlap=0)
        split_docs = splitter.split_text(merged)
        print(f'Before split total rows: {len(text)}\nAfter split total docs: {len(split_docs)}')
        return split_docs 
    else:
        print(F'Please upload only Excel files....')     


def initialize_rag_chatbot():
    global rag_chain, memory

    documents = get_data_ready(r"D:\LLMs\RAG_API_working\RAG_sales_data_customer_interset_classification\business-to-business (B2B) office supply store.xlsx")
    embedder = HuggingFaceEmbeddings()

    vector_store = FAISS.from_texts(documents, embedder)
    retriever = vector_store.as_retriever(search_kwargs={"k":40})



    template = """You are a Generator of A RETRIEVAL AUGMENTED GENERATION FOR BUSINESS TO BUSINESS SALES DATA\n
    The RAG system has a knowledge base of a Business2Business sales data(xlsx) of furniturs, electronic devices, office supplies and other things needed for an office.\n 
    You will be given a question from the user, Conversation history of yourself and the user and retrieved data or rows of the dataset related to the user's question.\n
    Your role is to answer the user's question by using the context of retrieved data.\n
    User's questions can be anything related to the office products. 

    Things to follow:
            1. If the user greets you, simply respond with "Hi. How can I help you?" without referencing any context.

            2. If the user's question cannot be answered based on the provided context Then try to answer based on the history given. If the question is completely different, then respond only with "Sorry! I don't know." - nothing more.

            3. When answering questions based on context, provide clear, concise responses without mentioning the context itself or explaining your process.

            4. Focus exclusively on answering the question with relevant information, avoiding unnecessary explanations about limitations, system design, or data sources.

            5. Try to provide answer with in 4 lines. 

            6. If the user ask for more detail then you can provide an elaborated answer.
            
            7. Relate the question with the given context to get clear answer. \n

    QUESTION: \n
    {question}\n\n
    CONVERSATION HISTORY:\n
    {chat_history}\n\n
    CONTEXT(Retrieved data related to the question):\n
    Column names of the below retrieved data (Note- Here order matters):\n['Row ID', 'Order ID', 'Order Date', 'Ship Date', 'Ship Mode',
        'Customer ID', 'Customer Name', 'Segment', 'Country', 'City', 'State',
        'Postal Code', 'Region', 'Product ID', 'Category', 'Sub-Category',
        'Product Name', 'Sales', 'Quantity', 'Discount', 'Profit']\n
    Retrieved data:\n
    {context}\n\n
    NOTE- THE USER IS **NOT INVESTIGATING** THE DATASET PROVIDED. INSTEAD, THE USER IS HERE TO ASK DETAILS ABOUT PRODUCTS TO BUY. SIMPLY, THE USER IS A COMMON CUSTOMER TO BUY OFFICE ITEMS IN US.\n
    Your answer to the question:
    QUESTION: \n
    {question}\n\n
    """

    prompt = PromptTemplate(
    input_variables=['question', 'chat_history', 'context'], 
    template=template
    )

    llm_G = ChatMistralAI(api_key="vLS0HGudf2d5dAILmDWNiPYEa7qQovXp", temperature=0, request_timeout=30, model_name="mistral-small-latest", )

    memory = ConversationBufferMemory(
        input_key="question", 
        memory_key="chat_history", 
        output_key="answer", 
        return_messages=True
    )

    rag_chain = ConversationalRetrievalChain.from_llm(
        llm=llm_G, 
        retriever=retriever, 
        memory=memory, 
        combine_docs_chain_kwargs={"prompt":prompt}, 
        rephrase_question=False, 
        verbose=True
    )

    return True


def initialize_classification_agent():
        
    global classification_chain
    # prompt_classify = """You are a classifer who's role is classifying whether the customer is intrested to buy the product or not based on the conversation.\n 
    # You will be given a conversation history of user and chatbot.\n
    # You MUST PROVIDE ONE WORD ANSWER (YES/NO)
    # CONVERSATION HISTORY:\n
    # {conv_hist}\n\n
    # YOUR FALSE POSITIVES AND FALSE NEGATIVES SHOULD BE VERY VERY LESS
    # LOOK THE CONVERSATION HISTORY BEFORE ANSWERING.
    # Whether the customer is willing to buy or not (YES/NO)"""

    prompt_classify = """
    You are a highly precise classifier tasked with determining whether a customer is genuinely interested in buying a product based on a conversation history.

    Criteria for Classification:
    - Look for explicit buying signals like:
    * Direct questions about pricing
    * Inquiries about product specifications
    * Requests for product comparisons
    * Discussions about product features
    * Indications of budget or purchasing intent

    Classification Guidelines:
    1. Carefully analyze the ENTIRE conversation history from start to finish
    2. Consider context, tone, and specific language used
    3. Be extremely conservative in your classification
    4. Minimize false positives and false negatives
    5. Provide ONLY a ONE-WORD answer: YES or NO

    Important Considerations:
    - A casual or exploratory conversation does NOT automatically mean YES
    - Look for concrete evidence of purchase intent
    - If unsure, default to NO
    - The goal is to accurately predict genuine buying interest

    CONVERSATION HISTORY:
    {conv_hist}

    The result should be the word (YES/NO) and confidence(Probability). use '-' as deliminator.: e.g, YES - 0.67
    **If the user asks anything about the price or shipping duration it enough to classify as YES.**
    Your Answer:    """

#     prompt_classify = """
# You are an advanced AI classifier specializing in detecting genuine buyer intent through nuanced conversation analysis.

# CONVERSATION HISTORY:
# {conv_hist}\n\n
# Classification Methodology:
# 1. Comprehensive Contextual Assessment
# - Analyze the ENTIRE conversation holistically
# - Evaluate not just keywords, but conversation trajectory
# - Assess depth of engagement and specificity of interest

# 2. Buying Intent Signal Hierarchy
# Primary Signals (Strong Indicators):
# * Explicit purchase timeline discussions
# * Specific budget allocation conversations
# * Detailed technical requirement explorations
# * Request for quotation or purchasing process details
# * Comparative analysis with intent to select

# Secondary Signals (Moderate Indicators):
# * Product feature deep-dive questions
# * Performance or compatibility inquiries
# * Hypothetical implementation scenarios
# * ROI or value proposition discussions

# 3. Confidence Scoring Mechanism
# - Use a probabilistic approach (0-1 scale)
# - Consider conversation length, interaction depth
# - Weight recent conversation segments more heavily
# - Penalize vague or exploratory language

# 4. Decision Framework
# - Default position: Skeptical (NO)
# - Require multiple, converging intent signals
# - Demand concrete evidence beyond casual interest
# - Minimize classification errors

# Classification Output Format:
# - First word: Definitive YES or NO
# - Second part (after '-'): Confidence probability of the First word(0.00-1.00)

# Critical Constraints:
# - ONE-WORD result mandatory
# - Probability must reflect rigorous analysis
# - No explanatory text allowed


# Your Precise Classification:"""

    prompt_c = PromptTemplate(
        input_variables=['conv_hist'],
        template=prompt_classify
    )

    llm_c = ChatMistralAI(api_key="vLS0HGudf2d5dAILmDWNiPYEa7qQovXp", temperature=0.9, request_timeout=30, model_name="mistral-small-latest", )

    classification_chain = LLMChain(
        llm=llm_c, 
        prompt = prompt_c, 
        output_key="answer"
    )
    return True 

def get_conv_ready_classification():
    history = memory.load_memory_variables('chat_history')
    conv_hist = []
    for i in history['chat_history']:
        if i.type == 'human':
            conv_hist.append({"Human":i.content})
        else:
            conv_hist.append({"AI":i.content})
    return conv_hist

class RateLimitError(Exception):
    pass

def fetch_with_retry(chain, prompt):
    """Execute the chain with exponential backoff retry logic for rate limits"""
    retries = 0
    backoff = INITIAL_BACKOFF
    
    while retries < MAX_RETRIES:
        try:
            return chain(prompt)
        except Exception as e:
            error_str = str(e).lower()
            
            if "429" in error_str or "rate limit" in error_str:
                retries += 1
                if retries >= MAX_RETRIES:
                    raise RateLimitError(f"Failed after {MAX_RETRIES} retries due to rate limiting") from e
                
                jitter = random.uniform(0.8, 1.2)
                sleep_time = min(backoff * jitter, MAX_BACKOFF)
                
                print(f"Rate limit hit. Retrying in {sleep_time:.2f} seconds (attempt {retries}/{MAX_RETRIES})")
                time.sleep(sleep_time)
                
                backoff = min(backoff * 2, MAX_BACKOFF)
            else:
                raise

st=datetime.now()
initialize_rag_chatbot()
initialize_classification_agent() 
en=datetime.now()
print(f'Time taken to initialize Chat bot + classification agent {(st-en).total_seconds()*1000} ms')


@app.route('/')
def index():
    return render_template('index.html')

@app.route('/chat', methods=['POST'])
def chat():
    # data = request.json
    data = request.form

    question = data.get("question", '')
    print(f"{question = }")
    response = fetch_with_retry(rag_chain, question)
    add_chatlogs(None, current_session_id, question, response['answer'], datetime.now())

    return jsonify({
        'answer':response['answer']
    })

@app.route('/classify', methods=['POST'])
def classify():    
    global memory, current_session_id
    response = fetch_with_retry(classification_chain, get_conv_ready_classification())
    print(f'------data to classify\n{get_conv_ready_classification()}\n-----------')
    print(f'--------------\nClassified: {response['answer']}\n-----------------')
    res, conf = response['answer'].split("-")
    add_result(None, current_session_id, res, conf)
    memory.clear()
    current_session_id = get_current_session_id()
    return res.strip()




if __name__=='__main__':
    app.run(debug=True, port=4000)


